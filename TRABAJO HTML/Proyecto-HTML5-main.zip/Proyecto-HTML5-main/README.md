# Proyecto-HTML5

## Proyecto para Lenguaje de marcas sobre html y CSS.
 * _Temática:_ Barroco musical 
 * _Plantilla:_ [html5up.net](https://html5up.net/escape-velocity)
 * _Hosting:_ [000webhost.com](https://es.000webhost.com)
 * _Web:_ [Historia del Barroco](https://barochistory.000webhostapp.com)

## Autora :computer:
* María Jesús Alloza Rodríguez
* :school:I.E.S. Gonzalo Nazareno :round_pushpin:(Dos Hermanas, Sevilla).
